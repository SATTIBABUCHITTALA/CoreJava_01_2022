package com.ashokit.book;

public class BookServiceImpl implements BookService {

	
	//annotations
	
	Book book=new Book();;
	
	public void setBookDetails() {
		book=new Book();
			book.setAuthorName("Bala Guru Swamy");
			book.setBookId("101F");
			book.setBookName("Core Java");
			book.setPublications("SV Publications");
			book.setPrice(500.75);
			book.setDiscountApplies(10);
	}
	
	
	
	

	@Override 
	public String getAuthorName(String bookId) {
		// TODO Auto-generated method stub
		return this.book.getAuthorName();
	}

	@Override
	public double getPrice(String bookId) {
		// TODO Auto-generated method stub
		return this.book.getPrice();
	}

	@Override
	public boolean isBookAvailable(String bookId) {
		// TODO Auto-generated method stub
		if(bookId =="101F")
		return true;
		else
			return false;
	}

	@Override
	public double getDiscountPercentage(String bookId) {
		// TODO Auto-generated method stub
		return this.book.getDiscountApplies();
	}
	
	
	

}
