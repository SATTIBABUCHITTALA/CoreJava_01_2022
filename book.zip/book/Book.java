package com.ashokit.book;

public class Book {

	
	private String bookId;
	
	private double  price;
	private String authorName;
	private String bookName;
	private String publications;
	private double discountApplies;
	
	
	public double getDiscountApplies() {
		return discountApplies;
	}
	public void setDiscountApplies(double discountApplies) {
		this.discountApplies = discountApplies;
	}
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
				this.bookId = bookId;
	}
	
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getPublications() {
		return publications;
	}
	public void setPublications(String publications) {
		this.publications = publications;
	}
	
	
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", price=" + price + ", authorName=" + authorName + ", bookName=" + bookName
				+ ", publications=" + publications + "]";
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	

}
