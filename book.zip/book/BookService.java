package com.ashokit.book;

public interface BookService {

	public String getAuthorName(String bookId);
	public double  getPrice(String bookId);
	public boolean isBookAvailable(String bookId);
	public double getDiscountPercentage(String bookId);
	
	
	
}
