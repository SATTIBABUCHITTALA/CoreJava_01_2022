package com.ashokit.book;

public class AccessBookDetails {

	public static void main(String args[]) {
		
		
		
		
		BookServiceImpl bookServiceImpl=new BookServiceImpl();
		bookServiceImpl.setBookDetails();
		
		System.out.println("AuthorName:- "+ bookServiceImpl.getAuthorName("101F"));
		
		System.out.println(bookServiceImpl.getDiscountPercentage("101F"));
		
		
	}
	
}
